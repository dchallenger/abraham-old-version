<div class="portlet">
	<div class="portlet-title">
		<div class="caption">Previous Employee Information</div>
		<div class="tools"><a class="collapse" href="javascript:;"></a></div>
	</div>
		<div class="portlet-body form">	</div>
</div>