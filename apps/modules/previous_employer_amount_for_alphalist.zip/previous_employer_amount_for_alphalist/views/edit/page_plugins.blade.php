<script src="{{ theme_path() }}plugins/select2/select2.min.js" type="text/javascript" ></script>
