<th width="15%">Employee Name</th>
<th width="24%">Company Name</th>
<th width="15%">Address</th>